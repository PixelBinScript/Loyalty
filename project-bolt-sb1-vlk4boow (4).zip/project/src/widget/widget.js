// Versión compilada del widget para Shopify
// Este archivo se servirá desde tu CDN
(function(){var e=document.createElement("script");e.src="https://tu-app.com/widget.js",e.async=!0,document.head.appendChild(e)})();